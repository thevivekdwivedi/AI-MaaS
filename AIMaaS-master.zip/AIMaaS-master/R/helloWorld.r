args = commandArgs(trailingOnly=TRUE)

myString <- "Hello World"
print(myString)
print(toString(args[1]))
