export class User {
  userId: String;
  password: String;
  userType: String;
  authenticated: boolean;
}
