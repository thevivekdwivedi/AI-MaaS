import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prospect-summary-limited',
  templateUrl: './prospect-summary-limited.component.html',
  styleUrls: ['./prospect-summary-limited.component.css']
})
export class ProspectSummaryLimitedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
