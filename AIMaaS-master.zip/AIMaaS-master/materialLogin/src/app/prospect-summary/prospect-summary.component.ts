import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prospect-summary',
  templateUrl: './prospect-summary.component.html',
  styleUrls: ['./prospect-summary.component.css']
})
export class ProspectSummaryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
