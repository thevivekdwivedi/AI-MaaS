import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-smo-landing',
  templateUrl: './smo-landing.component.html',
  styleUrls: ['./smo-landing.component.css']
})
export class SmoLandingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
